"""
Rate limiting middleware using in-memory sliding window.
For production use Redis instead of the in-memory store.

Limits:
  - Auth endpoints:      10 req/min  per IP
  - Payroll run:         5 req/min   per user
  - General API:         120 req/min per user
  - Calculator (public): 30 req/min  per IP
"""
import time
from collections import defaultdict, deque
from typing import Callable
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware


class SlidingWindowRateLimiter:
    def __init__(self):
        # key -> deque of timestamps
        self._windows: dict[str, deque] = defaultdict(deque)

    def is_allowed(self, key: str, limit: int, window_seconds: int) -> tuple[bool, int]:
        """Returns (allowed, retry_after_seconds)."""
        now = time.time()
        window = self._windows[key]

        # Remove timestamps outside the window
        cutoff = now - window_seconds
        while window and window[0] < cutoff:
            window.popleft()

        if len(window) >= limit:
            oldest = window[0]
            retry_after = int(window_seconds - (now - oldest)) + 1
            return False, retry_after

        window.append(now)
        return True, 0

    def remaining(self, key: str, limit: int, window_seconds: int) -> int:
        now = time.time()
        window = self._windows[key]
        cutoff = now - window_seconds
        active = sum(1 for t in window if t >= cutoff)
        return max(0, limit - active)


_limiter = SlidingWindowRateLimiter()

# Route pattern → (limit, window_seconds)
RATE_LIMITS = {
    "/auth/login":            (10, 60),
    "/auth/forgot-password":  (5, 60),
    "/auth/reset-password":   (10, 60),
    "/auth/register":         (5, 60),
    "/payroll/run":           (5, 60),
    "/payroll/preview":       (30, 60),
    "/payroll/calculate":     (30, 60),   # public endpoint
    "/import/employees":      (10, 60),
    "/export/":               (20, 60),
    "default":                (120, 60),
}


def get_limit(path: str) -> tuple[int, int]:
    for pattern, limit in RATE_LIMITS.items():
        if pattern != "default" and path.startswith(pattern):
            return limit
    return RATE_LIMITS["default"]


def get_client_key(request: Request, path: str) -> str:
    """Build rate limit key from IP + user token or IP alone for public routes."""
    ip = (
        request.headers.get("x-forwarded-for", "").split(",")[0].strip()
        or request.headers.get("x-real-ip", "")
        or (request.client.host if request.client else "unknown")
    )
    # For auth endpoints use IP only (no token yet)
    if path.startswith("/auth/") or path == "/payroll/calculate":
        return f"ip:{ip}:{path.split('?')[0]}"

    # For authenticated endpoints use token sub if available
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        token_prefix = auth[7:27]  # first 20 chars of token
        return f"user:{token_prefix}:{path.split('?')[0]}"

    return f"ip:{ip}:{path.split('?')[0]}"


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path

        # Skip health checks and docs
        if path in ("/health", "/", "/docs", "/openapi.json", "/redoc"):
            return await call_next(request)

        limit, window = get_limit(path)
        key = get_client_key(request, path)
        allowed, retry_after = _limiter.is_allowed(key, limit, window)
        remaining = _limiter.remaining(key, limit, window)

        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "detail": f"Rate limit exceeded. Try again in {retry_after}s.",
                    "retry_after": retry_after,
                },
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit": str(limit),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Window": str(window),
                },
            )

        response = await call_next(request)

        # Inject rate limit headers on all responses
        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Window"] = str(window)
        return response
