from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config import settings
from middleware.rate_limit import RateLimitMiddleware
from middleware.logging_mw import RequestLogMiddleware
import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

from routes import auth, employees, payroll, paystubs, time, company, reports, pay_periods, password_reset, export, import_routes, audit, users, webhooks, api_keys, pto, onboarding, offer_letters
import os

app = FastAPI(
    title="PayrollOS API",
    description="Complete payroll system API - built in 3 days",
    version="1.0.0",
)

app.add_middleware(RateLimitMiddleware)
app.add_middleware(RequestLogMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(auth.router)
app.include_router(employees.router)
app.include_router(payroll.router)
app.include_router(paystubs.router)
app.include_router(time.router)
app.include_router(company.router)
app.include_router(reports.router)
app.include_router(pay_periods.router)
app.include_router(password_reset.router)
app.include_router(export.router)
app.include_router(import_routes.router)
app.include_router(audit.router)
app.include_router(users.router)
app.include_router(webhooks.router)
app.include_router(api_keys.router)
app.include_router(pto.router)
app.include_router(onboarding.router)
app.include_router(offer_letters.router)

os.makedirs(settings.PAYSTUB_DIR, exist_ok=True)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "PayrollOS API"}


@app.get("/")
async def root():
    return {
        "service": "PayrollOS API",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "auth": "/auth/login | /auth/register",
            "employees": "/employees",
            "payroll_preview": "/payroll/preview",
            "payroll_run": "/payroll/run",
            "payroll_history": "/payroll/history",
            "payroll_calculator": "/payroll/calculate",
            "paystubs": "/paystubs/{id}",
            "paystub_pdf": "/paystubs/{id}/download",
            "time_entries": "/time",
            "company": "/company",
            "reports_ytd": "/reports/ytd-summary",
            "reports_dept": "/reports/by-department",
            "reports_employee": "/reports/employee-ytd",
            "reports_tax": "/reports/tax-liability",
            "pay_periods": "/pay-periods",
        }
    }
