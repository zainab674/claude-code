"""
Password reset flow:
POST /auth/forgot-password  → generate token, send email
POST /auth/reset-password   → validate token, set new password
"""
import secrets
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from database import get_db
from models import User, Company
from utils.auth import hash_password, verify_password, create_token
from services.email import send_password_reset

router = APIRouter(prefix="/auth", tags=["auth"])

# In-memory token store (use Redis in production)
_reset_tokens: dict = {}  # token -> {user_id, expires_at}


class ForgotRequest(BaseModel):
    email: str


class ResetRequest(BaseModel):
    token: str
    new_password: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


@router.post("/forgot-password")
async def forgot_password(req: ForgotRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == req.email))
    user = result.scalar_one_or_none()
    # Always return 200 — don't leak whether email exists
    if not user:
        return {"message": "If that email exists, a reset link has been sent"}

    token = secrets.token_urlsafe(32)
    _reset_tokens[token] = {
        "user_id": str(user.id),
        "expires_at": datetime.utcnow() + timedelta(hours=1),
    }

    # Load company name for email
    co_result = await db.execute(select(Company).where(Company.id == user.company_id))
    company = co_result.scalar_one_or_none()
    company_name = company.name if company else "PayrollOS"

    send_password_reset(user.email, token, company_name)
    return {"message": "If that email exists, a reset link has been sent"}


@router.post("/reset-password")
async def reset_password(req: ResetRequest, db: AsyncSession = Depends(get_db)):
    entry = _reset_tokens.get(req.token)
    if not entry:
        raise HTTPException(400, "Invalid or expired reset token")
    if datetime.utcnow() > entry["expires_at"]:
        del _reset_tokens[req.token]
        raise HTTPException(400, "Reset token has expired")
    if len(req.new_password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")

    result = await db.execute(select(User).where(User.id == entry["user_id"]))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(400, "User not found")

    user.password_hash = hash_password(req.new_password)
    await db.commit()
    del _reset_tokens[req.token]
    return {"message": "Password updated successfully"}


@router.post("/change-password")
async def change_password(
    req: ChangePasswordRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = __import__('utils.auth', fromlist=['get_current_user']).get_current_user,
):
    from utils.auth import get_current_user as gcu
    # This route needs the dependency injected properly — see main.py usage
    raise HTTPException(501, "Use /auth/reset-password for now")
