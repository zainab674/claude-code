import React, { useState, useEffect, useCallback } from 'react';
import * as api from '../services/api';

const fmt = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n || 0);
const fmtFull = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0);
const pct = (n) => `${Number(n || 0).toFixed(1)}%`;

function StatCard({ label, value, sub, color, trend, onClick }) {
  return (
    <div className="metric-card" onClick={onClick} style={onClick ? { cursor: 'pointer' } : {}}>
      <div className="metric-label">{label}</div>
      <div className="metric-value" style={color ? { color } : {}}>{value}</div>
      {sub && <div className="metric-delta">{sub}</div>}
    </div>
  );
}

function MiniBar({ data = [], color = 'var(--blue)' }) {
  if (!data.length) return null;
  const max = Math.max(...data.map(d => d.v), 1);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 48 }}>
      {data.map((d, i) => (
        <div key={i} title={`${d.l}: ${fmt(d.v)}`} style={{
          flex: 1, background: i === data.length - 1 ? color : color + '55',
          borderRadius: '2px 2px 0 0',
          height: `${Math.max((d.v / max) * 100, 4)}%`,
          transition: 'height 0.3s',
          cursor: 'default',
        }} />
      ))}
    </div>
  );
}

export default function Dashboard({ setPage }) {
  const year = new Date().getFullYear();
  const [ytd, setYtd] = useState(null);
  const [history, setHistory] = useState([]);
  const [employees, setEmployees] = useState(null);
  const [compliance, setCompliance] = useState(null);
  const [pending, setPending] = useState({ pto: 0, expenses: 0, leave: 0 });
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [y, h, e, c, ph, lv, hlt] = await Promise.allSettled([
        api.getYtdSummary(year),
        api.getPayrollHistory({ limit: 8 }),
        api.getEmployees({ status: 'active', limit: 1 }),
        api.prePayrollCheck(),
        api.getPtoRequests({ status: 'pending' }),
        api.getActiveLeave(),
        api.getHealth(),
      ]);
      if (y.status === 'fulfilled') setYtd(y.value);
      if (h.status === 'fulfilled') setHistory((h.value?.runs || []).slice(0, 8).reverse());
      if (e.status === 'fulfilled') setEmployees(e.value);
      if (c.status === 'fulfilled') setCompliance(c.value);
      if (ph.status === 'fulfilled' || lv.status === 'fulfilled') {
        setPending(p => ({
          ...p,
          pto: Array.isArray(ph.value) ? ph.value.length : 0,
          leave: lv.value?.count || 0,
        }));
      }
      if (hlt.status === 'fulfilled') setHealth(hlt.value);
    } catch (e) { /* ignore */ }
    setLoading(false);
    setLastRefresh(new Date());
  }, [year]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const t = setInterval(loadAll, 60000);
    return () => clearInterval(t);
  }, [loadAll]);

  const runChartData = history.map(r => ({
    l: r.created_at?.slice(0, 10) || '',
    v: Number(r.total_gross || 0),
  }));

  const empCount = employees?.total || 0;
  const avgPaycheck = ytd && ytd.run_count && empCount
    ? ytd.total_gross / ytd.run_count / empCount
    : 0;
  const lastRun = history[history.length - 1];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>
            Updated {lastRefresh.toLocaleTimeString()} · auto-refreshes every 60s
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn" onClick={loadAll} disabled={loading}>
            {loading ? '…' : '↻ Refresh'}
          </button>
          <button className="btn btn-primary" onClick={() => setPage?.('run-payroll')}>
            ▶ Run payroll
          </button>
        </div>
      </div>

      {/* Compliance alert banner */}
      {compliance && !compliance.can_proceed && (
        <div className="card" style={{ marginBottom: 16, border: '1px solid var(--red)', background: 'var(--red-bg)', cursor: 'pointer' }}
          onClick={() => setPage?.('compliance')}>
          <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 18 }}>✗</span>
            <div style={{ flex: 1 }}>
              <span style={{ fontWeight: 600, color: 'var(--red)' }}>
                {compliance.blocking_issues.length} compliance issue{compliance.blocking_issues.length > 1 ? 's' : ''} blocking payroll
              </span>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>
                {compliance.blocking_issues[0]?.message}
              </div>
            </div>
            <span style={{ fontSize: 12, color: 'var(--blue)' }}>Fix now →</span>
          </div>
        </div>
      )}

      {/* Pending items banner */}
      {(pending.pto > 0 || pending.leave > 0) && (
        <div className="card" style={{ marginBottom: 16, border: '1px solid var(--amber)', background: 'var(--amber-bg)' }}>
          <div style={{ padding: '10px 16px', display: 'flex', gap: 20, fontSize: 13 }}>
            {pending.pto > 0 && (
              <span style={{ color: 'var(--amber)', cursor: 'pointer', fontWeight: 500 }}
                onClick={() => setPage?.('pto')}>
                ⏳ {pending.pto} PTO request{pending.pto > 1 ? 's' : ''} pending
              </span>
            )}
            {pending.leave > 0 && (
              <span style={{ color: 'var(--amber)', cursor: 'pointer', fontWeight: 500 }}
                onClick={() => setPage?.('leave')}>
                📅 {pending.leave} employee{pending.leave > 1 ? 's' : ''} on leave today
              </span>
            )}
          </div>
        </div>
      )}

      {/* KPI grid */}
      <div className="metrics-grid" style={{ marginBottom: 16 }}>
        <StatCard
          label="Active employees"
          value={loading ? '…' : empCount}
          sub="Salaried + hourly"
          onClick={() => setPage?.('employees')}
        />
        <StatCard
          label={`${year} gross wages`}
          value={loading ? '…' : fmt(ytd?.total_gross)}
          sub={`${ytd?.run_count || 0} pay runs`}
          onClick={() => setPage?.('reports')}
        />
        <StatCard
          label={`${year} net paid`}
          value={loading ? '…' : fmt(ytd?.total_net)}
          sub={pct(ytd?.effective_tax_rate) + ' effective rate'}
          color="var(--green)"
          onClick={() => setPage?.('reports')}
        />
        <StatCard
          label="True payroll cost"
          value={loading ? '…' : fmt(ytd?.true_total_cost)}
          sub="Wages + employer taxes"
          onClick={() => setPage?.('reports')}
        />
        <StatCard
          label="Avg gross / paycheck"
          value={loading ? '…' : fmt(avgPaycheck)}
          sub="Per employee per run"
        />
        <StatCard
          label="Employer taxes YTD"
          value={loading ? '…' : fmt(ytd?.total_employer_taxes)}
          sub="FICA + FUTA"
          onClick={() => setPage?.('reports')}
        />
        <StatCard
          label="Pre-tax deductions YTD"
          value={loading ? '…' : fmt(ytd?.total_deductions)}
          sub="401k, health, FSA/HSA"
        />
        <StatCard
          label="System status"
          value={health?.status === 'ok' ? '✓ Healthy' : health?.status || '…'}
          sub="API + DB + cache"
          color={health?.status === 'ok' ? 'var(--green)' : 'var(--amber)'}
          onClick={() => setPage?.('settings')}
        />
      </div>

      <div className="two-col">
        {/* Payroll trend */}
        <div className="card">
          <div className="card-header">
            <h3>Payroll trend</h3>
            <span style={{ fontSize: 12, color: 'var(--text3)' }}>Last {runChartData.length} runs</span>
          </div>
          <div style={{ padding: '8px 16px 16px' }}>
            {runChartData.length === 0
              ? <div style={{ padding: 24, textAlign: 'center', color: 'var(--text3)', fontSize: 13 }}>No runs yet — run your first payroll</div>
              : <MiniBar data={runChartData} />
            }
          </div>
          {history.length > 0 && (
            <div>
              {history.slice(-5).reverse().map(r => (
                <div key={r.id} style={{ padding: '8px 16px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span style={{ color: 'var(--text2)' }}>{r.created_at?.slice(0, 10)}</span>
                  <span>{r.employee_count} emp</span>
                  <span style={{ fontWeight: 500 }}>{fmt(r.total_gross)}</span>
                  <span style={{ color: 'var(--green)' }}>{fmt(r.total_net)} net</span>
                  <span className={`badge badge-${r.status === 'completed' ? 'success' : 'warning'}`}>{r.status}</span>
                </div>
              ))}
            </div>
          )}
          <div style={{ padding: '8px 16px', borderTop: '1px solid var(--border)' }}>
            <button className="btn btn-sm" onClick={() => setPage?.('history')}>View all runs →</button>
          </div>
        </div>

        {/* Action shortcuts */}
        <div>
          {/* Last run summary */}
          {lastRun && (
            <div className="card" style={{ marginBottom: 12 }}>
              <div className="card-header"><h3>Last payroll run</h3></div>
              <div style={{ padding: 16 }}>
                <div className="preview-box">
                  {[
                    ['Date', lastRun.created_at?.slice(0, 10)],
                    ['Employees', lastRun.employee_count],
                    ['Gross wages', fmtFull(lastRun.total_gross)],
                    ['Employee taxes', fmtFull(lastRun.total_employee_taxes)],
                    ['Net paid', fmtFull(lastRun.total_net)],
                    ['Employer taxes', fmtFull(lastRun.total_employer_taxes)],
                  ].map(([l, v]) => (
                    <div key={l} className="preview-row">
                      <span style={{ color: 'var(--text2)', fontSize: 13 }}>{l}</span>
                      <span style={{ fontSize: 13, fontWeight: 400 }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Quick actions */}
          <div className="card">
            <div className="card-header"><h3>Quick actions</h3></div>
            <div style={{ padding: 8 }}>
              {[
                ['▶ Run payroll', 'run-payroll', 'btn-primary'],
                ['◉ Add employee', 'employees', ''],
                ['◌ PTO requests', 'pto', ''],
                ['✓ Compliance check', 'compliance', ''],
                ['▨ Analytics', 'analytics', ''],
                ['⇌ Reconcile', 'reconciliation', ''],
              ].map(([label, page, cls]) => (
                <button key={page} className={`btn ${cls}`}
                  onClick={() => setPage?.(page)}
                  style={{ width: '100%', textAlign: 'left', marginBottom: 4, justifyContent: 'flex-start' }}>
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* YTD tax breakdown */}
      {ytd && (
        <div className="card">
          <div className="card-header">
            <h3>YTD cost breakdown</h3>
            <button className="btn btn-sm" onClick={() => setPage?.('reports')}>Full report →</button>
          </div>
          <div style={{ padding: 16 }}>
            <div className="preview-box">
              {[
                ['Gross wages', fmt(ytd.total_gross), 'var(--text)'],
                ['Pre-tax deductions', `(${fmt(ytd.total_deductions)})`, 'var(--text2)'],
                ['Employee taxes withheld', `(${fmt(ytd.total_employee_taxes)})`, 'var(--text2)'],
                ['Net paid to employees', fmt(ytd.total_net), 'var(--green)'],
                ['+ Employer FICA + FUTA', fmt(ytd.total_employer_taxes), 'var(--text2)'],
                ['= True total payroll cost', fmt(ytd.true_total_cost), 'var(--text)'],
              ].map(([l, v, c]) => (
                <div key={l} className={`preview-row ${l.startsWith('=') ? 'total' : ''}`}>
                  <span style={{ color: 'var(--text2)' }}>{l}</span>
                  <span style={{ color: c, fontWeight: l.startsWith('=') ? 700 : 400 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
