"""
Email service — send paystubs, payroll summaries, and password resets.
Uses Python's built-in smtplib with STARTTLS.

Configure via .env:
    SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, FROM_EMAIL

If SMTP is not configured, emails are logged to console instead
(useful for development).
"""
import smtplib
import os
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from typing import Optional
from config import settings

logger = logging.getLogger("payrollos.email")


def _send(to: str, subject: str, html_body: str, pdf_path: Optional[str] = None) -> bool:
    """Send one email. Returns True on success."""
    if not settings.email_configured:
        logger.info("[email-dev] Would send to %s: %s", to, subject)
        return True   # silently succeed in dev

    msg = MIMEMultipart("mixed")
    msg["From"] = settings.FROM_EMAIL
    msg["To"] = to
    msg["Subject"] = subject
    msg.attach(MIMEText(html_body, "html"))

    if pdf_path and os.path.exists(pdf_path):
        with open(pdf_path, "rb") as f:
            part = MIMEApplication(f.read(), Name=os.path.basename(pdf_path))
            part["Content-Disposition"] = f'attachment; filename="{os.path.basename(pdf_path)}"'
            msg.attach(part)

    try:
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=15) as server:
            server.ehlo()
            server.starttls()
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            server.sendmail(settings.FROM_EMAIL, to, msg.as_string())
        logger.info("[email] Sent to %s: %s", to, subject)
        return True
    except Exception as e:
        logger.error("[email] Failed to send to %s: %s", to, e)
        return False


def send_paystub_notification(
    employee_email: str,
    employee_name: str,
    company_name: str,
    pay_date: str,
    net_pay: float,
    pdf_path: Optional[str] = None,
) -> bool:
    subject = f"Your paystub is ready — {company_name} ({pay_date})"
    html = f"""
    <div style="font-family:sans-serif;max-width:520px;margin:0 auto">
      <div style="background:#1a1a1a;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0;font-size:18px">{company_name}</h2>
        <p style="color:#aaa;margin:4px 0 0;font-size:13px">Payroll notification</p>
      </div>
      <div style="padding:24px;border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px">
        <p style="font-size:15px">Hi {employee_name},</p>
        <p>Your paystub for <strong>{pay_date}</strong> is ready.</p>
        <div style="background:#f5f5f5;padding:16px;border-radius:6px;margin:16px 0">
          <p style="margin:0;font-size:13px;color:#666">Net pay</p>
          <p style="margin:4px 0 0;font-size:28px;font-weight:700;color:#1a7a3c">${net_pay:,.2f}</p>
        </div>
        <p style="font-size:13px;color:#666">Log in to your employee portal to view your full paystub.</p>
      </div>
    </div>"""
    return _send(employee_email, subject, html, pdf_path)


def send_payroll_complete_notification(
    admin_email: str,
    company_name: str,
    pay_date: str,
    employee_count: int,
    total_gross: float,
    total_net: float,
    total_employer_taxes: float,
) -> bool:
    subject = f"Payroll complete — {company_name} ({pay_date})"
    html = f"""
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#1a1a1a;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">Payroll Complete</h2>
        <p style="color:#aaa;margin:4px 0 0;font-size:13px">{company_name} · {pay_date}</p>
      </div>
      <div style="padding:24px;border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px">
        <table style="width:100%;border-collapse:collapse">
          <tr style="border-bottom:1px solid #eee">
            <td style="padding:10px 0;color:#666;font-size:13px">Employees paid</td>
            <td style="padding:10px 0;font-weight:600;text-align:right">{employee_count}</td>
          </tr>
          <tr style="border-bottom:1px solid #eee">
            <td style="padding:10px 0;color:#666;font-size:13px">Total gross wages</td>
            <td style="padding:10px 0;font-weight:600;text-align:right">${total_gross:,.2f}</td>
          </tr>
          <tr style="border-bottom:1px solid #eee">
            <td style="padding:10px 0;color:#666;font-size:13px">Total net pay</td>
            <td style="padding:10px 0;font-weight:700;color:#1a7a3c;text-align:right">${total_net:,.2f}</td>
          </tr>
          <tr>
            <td style="padding:10px 0;color:#666;font-size:13px">Employer tax burden</td>
            <td style="padding:10px 0;font-weight:600;text-align:right">${total_employer_taxes:,.2f}</td>
          </tr>
        </table>
        <p style="font-size:12px;color:#999;margin-top:16px">
          True payroll cost: <strong>${total_gross + total_employer_taxes:,.2f}</strong>
        </p>
      </div>
    </div>"""
    return _send(admin_email, subject, html)


def send_password_reset(
    employee_email: str,
    reset_token: str,
    company_name: str,
    base_url: str = "http://localhost:3000",
) -> bool:
    reset_url = f"{base_url}/reset-password?token={reset_token}"
    subject = f"Reset your PayrollOS password — {company_name}"
    html = f"""
    <div style="font-family:sans-serif;max-width:520px;margin:0 auto">
      <div style="background:#1a1a1a;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">{company_name}</h2>
        <p style="color:#aaa;margin:4px 0 0;font-size:13px">Password reset request</p>
      </div>
      <div style="padding:24px;border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px">
        <p>We received a request to reset your PayrollOS password.</p>
        <p>Click the button below to set a new password. This link expires in <strong>1 hour</strong>.</p>
        <div style="text-align:center;margin:24px 0">
          <a href="{reset_url}" style="background:#1a1a1a;color:#fff;padding:12px 28px;
             border-radius:6px;text-decoration:none;font-weight:600;font-size:14px">
            Reset password
          </a>
        </div>
        <p style="font-size:12px;color:#999">
          If you didn't request this, ignore this email. Your password won't change.
          <br>Reset link: {reset_url}
        </p>
      </div>
    </div>"""
    return _send(employee_email, subject, html)


def send_welcome_email(
    employee_email: str,
    employee_name: str,
    company_name: str,
    temp_password: Optional[str] = None,
    login_url: str = "http://localhost:3000",
) -> bool:
    subject = f"Welcome to {company_name} — Your payroll account is ready"
    pw_section = f"""
        <div style="background:#f5f5f5;padding:12px 16px;border-radius:6px;margin:16px 0;font-family:monospace">
          Temporary password: <strong>{temp_password}</strong>
        </div>
        <p style="font-size:13px;color:#666">Please change your password after your first login.</p>
    """ if temp_password else ""

    html = f"""
    <div style="font-family:sans-serif;max-width:520px;margin:0 auto">
      <div style="background:#1a1a1a;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">Welcome to {company_name}</h2>
      </div>
      <div style="padding:24px;border:1px solid #e0e0e0;border-top:none;border-radius:0 0 8px 8px">
        <p>Hi {employee_name},</p>
        <p>Your employee account has been created. You can now access your paystubs, PTO balance, and more.</p>
        {pw_section}
        <div style="text-align:center;margin:20px 0">
          <a href="{login_url}" style="background:#1a1a1a;color:#fff;padding:12px 28px;
             border-radius:6px;text-decoration:none;font-weight:600;font-size:14px">
            Log in now
          </a>
        </div>
      </div>
    </div>"""
    return _send(employee_email, subject, html)
