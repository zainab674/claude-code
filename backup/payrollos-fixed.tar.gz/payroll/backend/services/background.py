"""
Background tasks — run after payroll completes (non-blocking).
Called via FastAPI BackgroundTasks after POST /payroll/run.

Tasks:
  1. Generate PDF paystub for every employee
  2. Email each employee their paystub (if email + SMTP configured)
  3. Email admin the payroll summary
  4. Fire payroll.run.completed webhook
  5. Create in-app notifications
  6. Accrue PTO for all eligible employees
"""
import logging
from datetime import datetime, date
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import select
from config import settings
from models import PayRun, PayRunItem, PayPeriod, Paystub, Employee, Company, User

logger = logging.getLogger("payrollos.background")

_engine = create_async_engine(settings.async_database_url, pool_size=3, max_overflow=5)
_Session = async_sessionmaker(_engine, expire_on_commit=False)


async def generate_paystub_pdfs_and_notify(pay_run_id: str):
    """Master background task — called after every payroll run."""
    logger.info("Background: starting post-run tasks for %s", pay_run_id[:8])
    async with _Session() as db:
        try:
            await _generate_pdfs(db, pay_run_id)
            await _send_notifications(db, pay_run_id)
            await _fire_webhook(db, pay_run_id)
            await _create_app_notifications(db, pay_run_id)
        except Exception as e:
            logger.error("Background task failed for run %s: %s", pay_run_id[:8], e)


async def _generate_pdfs(db: AsyncSession, pay_run_id: str):
    """Generate PDF paystubs for all employees in this run."""
    from services.pdf_generator import generate_paystub_pdf

    stubs_res = await db.execute(select(Paystub).where(Paystub.pay_run_id == pay_run_id))
    stubs = stubs_res.scalars().all()

    run_res = await db.execute(select(PayRun).where(PayRun.id == pay_run_id))
    run = run_res.scalar_one_or_none()
    if not run:
        return

    pp_res = await db.execute(select(PayPeriod).where(PayPeriod.id == run.pay_period_id))
    period = pp_res.scalar_one_or_none()

    co_res = await db.execute(select(Company).where(Company.id == run.company_id))
    company = co_res.scalar_one_or_none()

    generated = 0
    for stub in stubs:
        try:
            item_res = await db.execute(select(PayRunItem).where(PayRunItem.id == stub.pay_run_item_id))
            item = item_res.scalar_one_or_none()
            emp_res = await db.execute(select(Employee).where(Employee.id == stub.employee_id))
            emp = emp_res.scalar_one_or_none()
            if not item or not emp:
                continue

            emp_dict = {
                "id": str(emp.id), "first_name": emp.first_name,
                "last_name": emp.last_name, "job_title": emp.job_title or "",
                "department": emp.department or "", "filing_status": emp.filing_status,
                "state_code": emp.state_code, "pay_type": emp.pay_type,
                "pay_frequency": emp.pay_frequency,
            }
            co_dict = {
                "name": company.name if company else "Company",
                "address_line1": company.address_line1 if company else "",
                "city": company.city if company else "",
                "state": company.state if company else "",
                "zip": company.zip if company else "",
                "ein": company.ein if company else "",
            }
            period_dict = {
                "period_start": str(period.period_start) if period else "",
                "period_end": str(period.period_end) if period else "",
                "pay_date": str(period.pay_date) if period else "",
            }

            item_dict = {k: float(getattr(item, k) or 0) for k in [
                "gross_pay", "regular_pay", "overtime_pay", "bonus_pay", "reimbursement",
                "taxable_gross", "federal_income_tax", "state_income_tax",
                "social_security_tax", "medicare_tax", "additional_medicare_tax",
                "total_employee_taxes", "employer_social_security", "employer_medicare",
                "futa_tax", "total_employer_taxes", "health_insurance", "dental_insurance",
                "vision_insurance", "retirement_401k", "hsa", "fsa",
                "total_pretax_deductions", "garnishment", "total_posttax_deductions",
                "net_pay", "ytd_gross", "ytd_federal", "ytd_state", "ytd_ss",
                "ytd_medicare", "ytd_401k", "ytd_net",
            ]}

            pdf_path = generate_paystub_pdf(emp_dict, co_dict, period_dict, item_dict)
            if pdf_path:
                stub.pdf_path = pdf_path
                generated += 1

                # Email paystub to employee
                if emp.email:
                    from services.email import send_paystub_notification
                    send_paystub_notification(
                        employee_email=emp.email,
                        employee_name=f"{emp.first_name} {emp.last_name}",
                        company_name=company.name if company else "Company",
                        pay_date=period_dict["pay_date"],
                        net_pay=item_dict["net_pay"],
                        pdf_path=pdf_path,
                    )
        except Exception as e:
            logger.warning("PDF gen failed for stub %s: %s", str(stub.id)[:8], e)

    await db.commit()
    logger.info("Background: generated %d paystub PDFs", generated)


async def _send_notifications(db: AsyncSession, pay_run_id: str):
    """Email admin the payroll summary."""
    run_res = await db.execute(select(PayRun).where(PayRun.id == pay_run_id))
    run = run_res.scalar_one_or_none()
    if not run:
        return

    co_res = await db.execute(select(Company).where(Company.id == run.company_id))
    company = co_res.scalar_one_or_none()
    if not company:
        return

    pp_res = await db.execute(select(PayPeriod).where(PayPeriod.id == run.pay_period_id))
    period = pp_res.scalar_one_or_none()

    # Get admin emails
    admins_res = await db.execute(
        select(User).where(
            User.company_id == run.company_id,
            User.role == "admin",
            User.is_active == True,
        )
    )
    admins = admins_res.scalars().all()

    notify_email = company.notification_email
    if not notify_email and admins:
        notify_email = admins[0].email

    if notify_email:
        from services.email import send_payroll_complete_notification
        send_payroll_complete_notification(
            admin_email=notify_email,
            company_name=company.name,
            pay_date=str(period.pay_date) if period else "",
            employee_count=run.employee_count or 0,
            total_gross=float(run.total_gross or 0),
            total_net=float(run.total_net or 0),
            total_employer_taxes=float(run.total_employer_taxes or 0),
        )


async def _fire_webhook(db: AsyncSession, pay_run_id: str):
    """Fire payroll.run.completed webhook event."""
    try:
        run_res = await db.execute(select(PayRun).where(PayRun.id == pay_run_id))
        run = run_res.scalar_one_or_none()
        if not run:
            return
        from routes.webhooks import fire_event
        await fire_event("payroll.run.completed", str(run.company_id), {
            "pay_run_id": pay_run_id,
            "employee_count": run.employee_count or 0,
            "total_gross": float(run.total_gross or 0),
            "total_net": float(run.total_net or 0),
        })
    except Exception as e:
        logger.debug("Webhook fire failed: %s", e)


async def _create_app_notifications(db: AsyncSession, pay_run_id: str):
    """Create in-app notification for all admin users."""
    try:
        run_res = await db.execute(select(PayRun).where(PayRun.id == pay_run_id))
        run = run_res.scalar_one_or_none()
        if not run:
            return

        from routes.notifications import create_notification
        await create_notification(
            db=db,
            company_id=str(run.company_id),
            notif_type="payroll_complete",
            title=f"Payroll complete — {run.employee_count} employees",
            body=f"${float(run.total_gross or 0):,.2f} gross · ${float(run.total_net or 0):,.2f} net",
            action_url="history",
            severity="success",
        )
        await db.commit()
    except Exception as e:
        logger.debug("App notification creation failed: %s", e)
