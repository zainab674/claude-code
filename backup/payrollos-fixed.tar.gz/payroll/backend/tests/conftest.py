"""
pytest configuration and shared fixtures.
Run unit tests: pytest tests/test_calculator.py tests/test_extended.py -v
"""
import pytest
import sys
import os
from decimal import Decimal

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

os.environ.setdefault("DATABASE_URL", "postgresql://payroll:payroll_secret@localhost:5432/payrolldb")
os.environ.setdefault("JWT_SECRET", "test_jwt_secret_that_is_long_enough_for_testing_purposes")
os.environ.setdefault("APP_ENV", "development")


@pytest.fixture(scope="session")
def calc():
    from services.calculator import PayrollCalculator
    return PayrollCalculator()


@pytest.fixture
def inp():
    def _make(**kwargs):
        from services.calculator import PayCalculationInput
        defaults = dict(
            pay_type="salary", pay_rate=Decimal("60000"), pay_frequency="biweekly",
            filing_status="single", state_code="NY",
            regular_hours=Decimal("80"), overtime_hours=Decimal("0"),
            health_insurance_deduction=Decimal("0"), dental_deduction=Decimal("0"),
            vision_deduction=Decimal("0"), retirement_401k_pct=Decimal("0"),
            hsa_deduction=Decimal("0"), garnishment_amount=Decimal("0"),
            reimbursement=Decimal("0"), bonus_pay=Decimal("0"),
            ytd_gross=Decimal("0"), ytd_ss_wages=Decimal("0"),
            exempt_from_federal=False, exempt_from_state=False,
        )
        defaults.update({k: (Decimal(str(v)) if isinstance(v, (int, float)) else v)
                         for k, v in kwargs.items()})
        return PayCalculationInput(**defaults)
    return _make


@pytest.fixture(scope="session")
def api_base():
    return os.getenv("PAYROLLOS_TEST_URL", "http://localhost:8000")


@pytest.fixture(scope="session")
def auth_token(api_base):
    try:
        import httpx
        r = httpx.post(f"{api_base}/auth/login", json={
            "email": os.getenv("PAYROLLOS_TEST_EMAIL", "admin@acme.com"),
            "password": os.getenv("PAYROLLOS_TEST_PASSWORD", "Admin123!"),
        }, timeout=5)
        if r.status_code == 200:
            return r.json()["access_token"]
    except Exception:
        pass
    return None


@pytest.fixture(scope="session")
def client(api_base, auth_token):
    try:
        import httpx
        headers = {"Authorization": f"Bearer {auth_token}"} if auth_token else {}
        return httpx.Client(base_url=api_base, headers=headers, timeout=30)
    except ImportError:
        pytest.skip("httpx not installed")
