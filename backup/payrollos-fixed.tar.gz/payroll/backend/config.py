"""
Application configuration via environment variables.
All settings have sensible defaults for development.
Production requires JWT_SECRET and DATABASE_URL to be set explicitly.
"""
from pydantic_settings import BaseSettings
from pydantic import field_validator
from typing import Optional
import os


class Settings(BaseSettings):
    # ── Database ───────────────────────────────────────────────
    DATABASE_URL: str = "postgresql://payroll:payroll_secret@localhost:5432/payrolldb"

    # ── JWT Auth ───────────────────────────────────────────────
    JWT_SECRET: str = "change_this_to_a_long_random_string_in_production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 480  # 8 hours

    # ── Redis ──────────────────────────────────────────────────
    REDIS_URL: str = ""  # empty = use in-memory fallback

    # ── Encryption ────────────────────────────────────────────
    SSN_ENCRYPTION_KEY: str = ""  # empty = store plaintext (dev only)

    # ── CORS ──────────────────────────────────────────────────
    CORS_ORIGINS: str = "http://localhost:3000"

    # ── File storage ──────────────────────────────────────────
    PAYSTUB_DIR: str = "./paystubs"
    DOC_STORAGE_PATH: str = "./documents"

    # ── Email ──────────────────────────────────────────────────
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    FROM_EMAIL: str = "payroll@company.com"

    # ── App ────────────────────────────────────────────────────
    APP_ENV: str = "development"  # development | production
    LOG_FORMAT: str = "text"       # text | json
    LOG_LEVEL: str = "INFO"
    APP_NAME: str = "PayrollOS"
    APP_VERSION: str = "1.0.0"

    # ── Security ──────────────────────────────────────────────
    BCRYPT_ROUNDS: int = 12
    MAX_LOGIN_ATTEMPTS: int = 5
    RATE_LIMIT_ENABLED: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"

    @property
    def is_production(self) -> bool:
        return self.APP_ENV.lower() == "production"

    @property
    def cors_origins_list(self) -> list:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def async_database_url(self) -> str:
        """Convert postgres:// to postgresql+asyncpg:// for SQLAlchemy."""
        url = self.DATABASE_URL
        if url.startswith("postgres://"):
            url = url.replace("postgres://", "postgresql+asyncpg://", 1)
        elif url.startswith("postgresql://"):
            url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
        return url

    @property
    def email_configured(self) -> bool:
        return bool(self.SMTP_HOST and self.SMTP_USER)


settings = Settings()
