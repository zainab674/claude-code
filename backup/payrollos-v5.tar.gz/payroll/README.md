# PayrollOS — Complete Payroll System (3-Day Build)

A full-stack payroll SaaS built with FastAPI + PostgreSQL + React.
All 15 original milestones compressed into 3 days of work.

---

## What's built

| Layer | Stack |
|---|---|
| Backend API | FastAPI (Python 3.12) + SQLAlchemy async |
| Database | PostgreSQL 16 with full schema |
| Payroll engine | Custom Python calculator (2024 IRS brackets) |
| PDF generator | ReportLab (zero cost, no API) |
| Frontend | React 18 (single-file, no heavy deps) |
| Auth | JWT (python-jose + bcrypt) |
| Container | Docker Compose |
| Deploy | DigitalOcean / AWS ECS / Vercel |

## Features

- ✅ Employee CRUD (salary, hourly, contract)
- ✅ Payroll preview before approval
- ✅ Full payroll run — saves all results to DB
- ✅ Federal income tax (2024 brackets, all filing statuses)
- ✅ State income tax (all 50 states)
- ✅ FICA: Social Security (6.2%), Medicare (1.45%)
- ✅ Additional Medicare (0.9% over $200k)
- ✅ SS wage base cap ($168,600 for 2024)
- ✅ FUTA ($7k wage base, 0.6%)
- ✅ Pre-tax deductions: health, dental, vision, 401k, HSA
- ✅ Post-tax: garnishments
- ✅ YTD accumulators per employee
- ✅ PDF paystub generation (ReportLab)
- ✅ Payroll history with audit trail
- ✅ Paycheck calculator (public endpoint)
- ✅ Employer true-cost calculator
- ✅ JWT authentication
- ✅ 25+ unit tests for the calculator

---

## Quick Start (Docker — 3 commands)

```bash
git clone https://github.com/your-org/payrollos
cd payrollos
docker compose up
```

Open http://localhost:3000  
Login: `admin@acme.com` / `Admin123!`  
API docs: http://localhost:8000/docs

---

## Local Dev (without Docker)

### 1. PostgreSQL
```bash
psql -U postgres -c "CREATE DATABASE payrolldb;"
psql -U postgres -c "CREATE USER payroll WITH PASSWORD 'payroll_secret';"
psql -U postgres -c "GRANT ALL ON DATABASE payrolldb TO payroll;"
psql -U payroll payrolldb < database/init.sql
```

### 2. Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Edit DATABASE_URL if needed
uvicorn main:app --reload
# → http://localhost:8000/docs
```

### 3. Frontend
```bash
cd frontend
npm install
npm start
# → http://localhost:3000
```

---

## API Reference

All endpoints except `/auth/*` and `/payroll/calculate` require `Authorization: Bearer <token>`.

### Auth
```
POST /auth/login         { email, password }   → { access_token, user }
POST /auth/register      { company_name, email, password, first_name, last_name }
```

### Employees
```
GET    /employees               List (supports ?search=&status=&department=)
POST   /employees               Create
GET    /employees/{id}          Get one
PUT    /employees/{id}          Update
DELETE /employees/{id}          Soft-terminate
```

### Payroll
```
POST /payroll/preview           Preview without saving
POST /payroll/run               Run payroll, save to DB, generate paystubs
GET  /payroll/history           List past runs
GET  /payroll/history/{id}      Get run with per-employee breakdown
POST /payroll/calculate         Public paycheck calculator (no auth)
```

### Paystubs
```
GET  /paystubs                  List (supports ?employee_id=)
GET  /paystubs/{id}             Full paystub data (JSON)
GET  /paystubs/{id}/download    Stream PDF
```

---

## Payroll Preview / Run Request Body

```json
{
  "period_start": "2026-03-01",
  "period_end":   "2026-03-15",
  "pay_date":     "2026-03-20",
  "employee_ids": null,
  "hours_overrides": [
    {
      "employee_id":   "uuid",
      "regular_hours": 80,
      "overtime_hours": 5,
      "bonus_pay":     500,
      "commission_pay": 0,
      "reimbursement":  0
    }
  ],
  "notes": "March 1-15 run"
}
```

## Calculator Request Body

```json
{
  "pay_type":          "salary",
  "annual_salary":     95000,
  "pay_frequency":     "biweekly",
  "filing_status":     "single",
  "state_code":        "NY",
  "regular_hours":     80,
  "overtime_hours":    0,
  "health_insurance":  300,
  "retirement_401k_pct": 0.06,
  "bonus_pay":         0
}
```

---

## Running Tests

```bash
cd backend
pytest tests/ -v
```

25 test cases covering:
- Salaried and hourly gross pay calculations
- All filing statuses (single, married, head of household)
- SS wage base cap enforcement
- FUTA wage base cap enforcement
- Pre-tax deductions reduce taxable gross
- Reimbursements not taxed
- State tax rates (TX=0%, FL=0%, NY, CA)
- Employer tax parity (SS, Medicare)
- Net pay formula correctness
- Net pay never goes negative

---

## File Structure

```
payrollos/
├── docker-compose.yml
├── deploy.sh
├── database/
│   └── init.sql                 Full PostgreSQL schema + seed data
├── backend/
│   ├── main.py                  FastAPI app
│   ├── config.py                Settings (pydantic-settings)
│   ├── database.py              Async SQLAlchemy engine
│   ├── models.py                All ORM models
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── alembic/                 Migrations
│   ├── routes/
│   │   ├── auth.py              Login / register
│   │   ├── employees.py         CRUD
│   │   ├── payroll.py           Preview, run, history, calculator
│   │   └── paystubs.py          List, view, PDF download
│   ├── services/
│   │   ├── calculator.py        Payroll calculation engine
│   │   └── pdf_generator.py     ReportLab paystub PDF
│   ├── utils/
│   │   └── auth.py              JWT + bcrypt
│   └── tests/
│       └── test_calculator.py   25 unit tests
└── frontend/
    ├── package.json
    ├── Dockerfile
    └── src/
        ├── App.js               All pages: Dashboard, Employees, Run,
        │                        History, Paystubs, Calculators
        ├── App.css              Full stylesheet
        ├── index.js
        └── services/
            └── api.js           All API calls
```

---

## Phase 2 (not included — needs licensed provider)

- ACH / direct deposit → Dwolla or Stripe Payouts
- IRS 941 quarterly filing → TaxJar or PayrollAPI.com
- W-2 generation → ADP or Gusto APIs
- State SUI rates → state-specific tables
- Benefits management → carrier integrations
- Garnishment order management

---

## Disclaimer

Tax calculations are estimates based on 2024 IRS tables.
**Do not use for actual payroll without a licensed payroll provider.**
Consult a CPA or payroll compliance expert before going live.
