import React, { useState, useEffect, useCallback } from 'react';
import * as api from '../services/api';

const today = () => new Date().toISOString().split('T')[0];
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—';
const fmtHrs = (h) => `${Number(h || 0).toFixed(2)}h`;

export default function TimeTracking() {
  const [employees, setEmployees] = useState([]);
  const [entries, setEntries] = useState([]);
  const [filters, setFilters] = useState({ employee_id: '', start_date: today(), end_date: today() });
  const [form, setForm] = useState({
    employee_id: '', entry_date: today(), entry_type: 'work',
    regular_hours: 8, overtime_hours: 0, notes: '',
  });
  const [showForm, setShowForm] = useState(false);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getEmployees({ status: 'active', pay_type: 'hourly' }).then(r => setEmployees(r.employees || []));
  }, []);

  const loadEntries = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.getTimeEntries({
        employee_id: filters.employee_id || undefined,
        start_date: filters.start_date || undefined,
        end_date: filters.end_date || undefined,
      });
      setEntries(r || []);
      if (filters.employee_id && filters.start_date && filters.end_date) {
        const s = await api.getTimeSummary(filters.employee_id, filters.start_date, filters.end_date);
        setSummary(s);
      } else {
        setSummary(null);
      }
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [filters]);

  useEffect(() => { loadEntries(); }, [loadEntries]);

  const saveEntry = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.createTimeEntry(form);
      setShowForm(false);
      setForm({ employee_id: '', entry_date: today(), entry_type: 'work', regular_hours: 8, overtime_hours: 0, notes: '' });
      loadEntries();
    } catch (err) { setError(err.message); }
  };

  const approve = async (id) => {
    await api.updateTimeEntry(id, { approved: true });
    loadEntries();
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this entry?')) return;
    await api.deleteTimeEntry(id);
    loadEntries();
  };

  const totalReg = entries.reduce((s, e) => s + Number(e.regular_hours || 0), 0);
  const totalOt = entries.reduce((s, e) => s + Number(e.overtime_hours || 0), 0);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Time Tracking</h1>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>+ Log Hours</button>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      {/* ── Log form ──────────────────────────── */}
      {showForm && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><h3>Log time entry</h3><button className="btn btn-sm" onClick={() => setShowForm(false)}>Cancel</button></div>
          <form onSubmit={saveEntry} style={{ padding: 16 }}>
            <div className="form-grid">
              <div className="form-group">
                <label>Employee *</label>
                <select value={form.employee_id} onChange={e => setForm(f => ({ ...f, employee_id: e.target.value }))} required>
                  <option value="">Select employee...</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.full_name} ({e.pay_type})</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Date *</label>
                <input type="date" value={form.entry_date} onChange={e => setForm(f => ({ ...f, entry_date: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label>Type</label>
                <select value={form.entry_type} onChange={e => setForm(f => ({ ...f, entry_type: e.target.value }))}>
                  {['work','pto','sick','holiday','unpaid'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Regular hours</label>
                <input type="number" step="0.25" min="0" max="24" value={form.regular_hours}
                  onChange={e => setForm(f => ({ ...f, regular_hours: Number(e.target.value) }))} />
              </div>
              <div className="form-group">
                <label>Overtime hours</label>
                <input type="number" step="0.25" min="0" max="24" value={form.overtime_hours}
                  onChange={e => setForm(f => ({ ...f, overtime_hours: Number(e.target.value) }))} />
              </div>
              <div className="form-group">
                <label>Notes</label>
                <input type="text" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Optional" />
              </div>
            </div>
            <button className="btn btn-primary" type="submit">Save entry</button>
          </form>
        </div>
      )}

      {/* ── Filters ───────────────────────────── */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div style={{ padding: '12px 16px', display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div className="form-group" style={{ margin: 0, minWidth: 180 }}>
            <label>Employee</label>
            <select value={filters.employee_id} onChange={e => setFilters(f => ({ ...f, employee_id: e.target.value }))}>
              <option value="">All employees</option>
              {employees.map(e => <option key={e.id} value={e.id}>{e.full_name}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>From</label>
            <input type="date" value={filters.start_date} onChange={e => setFilters(f => ({ ...f, start_date: e.target.value }))} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>To</label>
            <input type="date" value={filters.end_date} onChange={e => setFilters(f => ({ ...f, end_date: e.target.value }))} />
          </div>
          <button className="btn" onClick={loadEntries}>↻ Refresh</button>
        </div>
      </div>

      {/* ── Summary banner ────────────────────── */}
      {summary && (
        <div className="metrics-grid" style={{ gridTemplateColumns: 'repeat(3,1fr)', marginBottom: 16 }}>
          <div className="metric-card"><div className="metric-label">Regular hours</div><div className="metric-value">{fmtHrs(summary.regular_hours)}</div></div>
          <div className="metric-card"><div className="metric-label">Overtime hours</div><div className="metric-value">{fmtHrs(summary.overtime_hours)}</div></div>
          <div className="metric-card"><div className="metric-label">Total hours</div><div className="metric-value">{fmtHrs(summary.total_hours)}</div></div>
        </div>
      )}

      {/* ── Entries table ─────────────────────── */}
      <div className="card">
        <div className="card-header">
          <h3>Time entries <span className="count-badge">{entries.length}</span></h3>
          <span style={{ fontSize: 12, color: 'var(--text3)' }}>
            Reg: {fmtHrs(totalReg)} · OT: {fmtHrs(totalOt)} · Total: {fmtHrs(totalReg + totalOt)}
          </span>
        </div>
        <table className="table">
          <thead>
            <tr><th>Employee</th><th>Date</th><th>Type</th><th>Reg</th><th>OT</th><th>Notes</th><th>Approved</th><th></th></tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={8} className="empty">Loading...</td></tr>}
            {!loading && entries.length === 0 && <tr><td colSpan={8} className="empty">No entries found</td></tr>}
            {entries.map(e => (
              <tr key={e.id}>
                <td style={{ fontFamily: 'monospace', fontSize: 11 }}>{e.employee_id.slice(0, 8)}…</td>
                <td>{fmtDate(e.entry_date)}</td>
                <td><span className={`badge badge-${e.entry_type === 'work' ? 'info' : e.entry_type === 'pto' ? 'success' : 'warning'}`}>{e.entry_type}</span></td>
                <td>{fmtHrs(e.regular_hours)}</td>
                <td style={{ color: e.overtime_hours > 0 ? 'var(--amber)' : 'inherit' }}>{fmtHrs(e.overtime_hours)}</td>
                <td style={{ color: 'var(--text3)', fontSize: 12 }}>{e.notes || '—'}</td>
                <td>
                  {e.approved
                    ? <span className="badge badge-success">✓ Yes</span>
                    : <button className="btn btn-sm" onClick={() => approve(e.id)}>Approve</button>}
                </td>
                <td>
                  <button className="btn btn-sm btn-danger" onClick={() => remove(e.id)}>×</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
