import React, { useState, useEffect } from 'react';

const BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';
const tkn = () => localStorage.getItem('payroll_token');

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tkn()}`, ...opts.headers },
  });
  if (!res.ok) { const e = await res.json().catch(() => ({ detail: res.statusText })); throw new Error(e.detail); }
  if (res.status === 204) return null;
  return res.json();
}

const EVENTS = [
  'payroll.run.completed',
  'payroll.run.failed',
  'employee.created',
  'employee.updated',
  'employee.terminated',
  'paystub.generated',
];

export default function Webhooks() {
  const [hooks, setHooks] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ url: '', secret: '', events: '*' });
  const [customEvents, setCustomEvents] = useState([]);
  const [useCustom, setUseCustom] = useState(false);
  const [testing, setTesting] = useState({});
  const [testResult, setTestResult] = useState({});
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try { const r = await req('/webhooks'); setHooks(r || []); }
    catch (e) { setError(e.message); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const create = async (e) => {
    e.preventDefault(); setError('');
    const events = useCustom ? customEvents.join(',') : '*';
    try {
      await req('/webhooks', { method: 'POST', body: JSON.stringify({ ...form, events }) });
      setShowForm(false);
      setForm({ url: '', secret: '', events: '*' });
      load();
    } catch (err) { setError(err.message); }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this webhook?')) return;
    try { await req(`/webhooks/${id}`, { method: 'DELETE' }); load(); }
    catch (err) { setError(err.message); }
  };

  const test = async (id) => {
    setTesting(t => ({ ...t, [id]: true }));
    try {
      const r = await req(`/webhooks/${id}/test`, { method: 'POST' });
      setTestResult(t => ({ ...t, [id]: r }));
    } catch (err) { setTestResult(t => ({ ...t, [id]: { success: false, error: err.message } })); }
    setTesting(t => ({ ...t, [id]: false }));
  };

  const genSecret = () => {
    const arr = new Uint8Array(24);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1>Webhooks <span className="count-badge">{hooks.length}</span></h1>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>+ Add webhook</button>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      {showForm && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><h3>Register webhook</h3><button className="btn btn-sm" onClick={() => setShowForm(false)}>Cancel</button></div>
          <form onSubmit={create} style={{ padding: 16 }}>
            <div className="form-group">
              <label>Endpoint URL *</label>
              <input type="url" value={form.url} onChange={e => setForm(f => ({ ...f, url: e.target.value }))}
                placeholder="https://your-server.com/payroll-webhook" required />
            </div>
            <div className="form-group">
              <label>Signing secret *</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" value={form.secret} onChange={e => setForm(f => ({ ...f, secret: e.target.value }))}
                  placeholder="Shared HMAC secret" required style={{ flex: 1 }} />
                <button type="button" className="btn" onClick={() => setForm(f => ({ ...f, secret: genSecret() }))}>
                  Generate
                </button>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>
                Requests are signed with HMAC-SHA256. Verify the X-PayrollOS-Signature header on your server.
              </div>
            </div>
            <div className="form-group">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <input type="checkbox" id="customev" checked={useCustom} onChange={e => setUseCustom(e.target.checked)} style={{ width: 'auto' }} />
                <label htmlFor="customev" style={{ cursor: 'pointer', fontSize: 13 }}>Subscribe to specific events only (default: all)</label>
              </div>
              {useCustom && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, padding: 12, background: 'var(--bg2)', borderRadius: 6 }}>
                  {EVENTS.map(ev => (
                    <label key={ev} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, cursor: 'pointer' }}>
                      <input type="checkbox" checked={customEvents.includes(ev)} style={{ width: 'auto' }}
                        onChange={e => setCustomEvents(c => e.target.checked ? [...c, ev] : c.filter(x => x !== ev))} />
                      {ev}
                    </label>
                  ))}
                </div>
              )}
            </div>
            <button className="btn btn-primary" type="submit">Register webhook</button>
          </form>
        </div>
      )}

      {/* Webhook list */}
      {loading && <div style={{ padding: 32, textAlign: 'center', color: 'var(--text3)' }}>Loading…</div>}

      {!loading && hooks.length === 0 && (
        <div className="card" style={{ padding: 32, textAlign: 'center', color: 'var(--text3)' }}>
          <div style={{ fontSize: 24, marginBottom: 12 }}>⇅</div>
          <div style={{ fontWeight: 500, marginBottom: 6 }}>No webhooks registered</div>
          <div style={{ fontSize: 13 }}>Register an endpoint to receive real-time payroll events.</div>
        </div>
      )}

      {hooks.map(hook => (
        <div key={hook.id} className="card" style={{ marginBottom: 12 }}>
          <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 500, fontFamily: 'monospace', fontSize: 13 }}>{hook.url}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>
                Events: <span style={{ fontFamily: 'monospace' }}>{hook.events}</span>
                {hook.last_triggered && <span style={{ marginLeft: 12 }}>Last triggered: {new Date(hook.last_triggered).toLocaleDateString()}</span>}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className={`badge badge-${hook.is_active ? 'success' : 'danger'}`}>{hook.is_active ? 'Active' : 'Inactive'}</span>
              <button className="btn btn-sm" onClick={() => test(hook.id)} disabled={testing[hook.id]}>
                {testing[hook.id] ? 'Testing…' : '↻ Test'}
              </button>
              <button className="btn btn-sm btn-danger" onClick={() => remove(hook.id)}>Delete</button>
            </div>
          </div>
          {testResult[hook.id] && (
            <div style={{ padding: '8px 16px 12px', borderTop: '1px solid var(--border)', fontSize: 12 }}>
              <span className={`badge badge-${testResult[hook.id].success ? 'success' : 'danger'}`}>
                {testResult[hook.id].success ? `✓ ${testResult[hook.id].status_code}` : `✗ Failed: ${testResult[hook.id].error || testResult[hook.id].status_code}`}
              </span>
            </div>
          )}
        </div>
      ))}

      {/* Payload reference */}
      <div className="card">
        <div className="card-header"><h3>Payload format</h3></div>
        <div style={{ padding: 16 }}>
          <pre style={{ fontSize: 12, background: 'var(--bg2)', padding: 16, borderRadius: 8, overflow: 'auto', margin: 0, lineHeight: 1.6 }}>{`{
  "event": "payroll.run.completed",
  "timestamp": "2026-03-15T12:00:00Z",
  "company_id": "uuid",
  "data": {
    "pay_run_id": "uuid",
    "employee_count": 24,
    "total_gross": 47140.00,
    "total_net": 34106.00
  }
}`}</pre>
          <div style={{ marginTop: 12, fontSize: 12, color: 'var(--text2)', lineHeight: 1.8 }}>
            <div>• All requests include a <code style={{ background: 'var(--bg3)', padding: '1px 4px', borderRadius: 3 }}>X-PayrollOS-Signature</code> header (HMAC-SHA256).</div>
            <div>• Verify: <code style={{ background: 'var(--bg3)', padding: '1px 4px', borderRadius: 3 }}>sha256=HMAC(secret, body)</code></div>
            <div>• Return <strong>2xx</strong> to acknowledge. Failed deliveries retry 3× with exponential backoff.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
