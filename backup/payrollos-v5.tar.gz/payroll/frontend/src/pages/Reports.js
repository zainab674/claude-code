import React, { useState, useEffect } from 'react';
import * as api from '../services/api';

const fmt = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0);
const pct = (n) => `${Number(n || 0).toFixed(2)}%`;

function MetricCard({ label, value, sub, accent }) {
  return (
    <div className="metric-card">
      <div className="metric-label">{label}</div>
      <div className="metric-value" style={accent ? { color: 'var(--green)' } : {}}>{value}</div>
      {sub && <div className="metric-delta">{sub}</div>}
    </div>
  );
}

export default function Reports() {
  const year = new Date().getFullYear();
  const [tab, setTab] = useState('ytd');
  const [ytd, setYtd] = useState(null);
  const [dept, setDept] = useState(null);
  const [empYtd, setEmpYtd] = useState(null);
  const [tax, setTax] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.getYtdSummary(year),
      api.getByDepartment(year),
      api.getEmployeeYtd(year),
      api.getTaxLiability(year),
    ]).then(([y, d, e, t]) => {
      setYtd(y); setDept(d); setEmpYtd(e); setTax(t);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [year]);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Reports <span className="count-badge">{year}</span></h1>
        <div className="tab-bar" style={{ margin: 0 }}>
          {[['ytd','YTD Summary'],['dept','By Department'],['emp','Per Employee'],['tax','Tax Liability']].map(([id, label]) => (
            <button key={id} className={`tab-btn ${tab === id ? 'active' : ''}`} onClick={() => setTab(id)}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {loading && <div style={{ padding: 32, textAlign: 'center', color: 'var(--text3)' }}>Loading reports...</div>}

      {/* ── YTD Summary ─────────────────────── */}
      {tab === 'ytd' && ytd && (
        <>
          <div className="metrics-grid">
            <MetricCard label="Total Gross Wages" value={fmt(ytd.total_gross)} sub={`${ytd.run_count} pay runs`} />
            <MetricCard label="Employee Taxes Withheld" value={fmt(ytd.total_employee_taxes)} sub={pct(ytd.effective_tax_rate) + ' effective rate'} />
            <MetricCard label="Employer Tax Cost" value={fmt(ytd.total_employer_taxes)} sub="FICA + FUTA" />
            <MetricCard label="Total Net Paid" value={fmt(ytd.total_net)} accent sub="After all deductions" />
          </div>
          <div className="two-col">
            <div className="card">
              <div className="card-header"><h3>Payroll cost summary</h3></div>
              <div style={{ padding: 16 }}>
                <div className="preview-box">
                  {[
                    ['Gross wages', fmt(ytd.total_gross)],
                    ['Pre-tax deductions', `(${fmt(ytd.total_deductions)})`],
                    ['Employee taxes withheld', `(${fmt(ytd.total_employee_taxes)})`],
                    ['Net paid to employees', fmt(ytd.total_net)],
                    ['+ Employer FICA/FUTA cost', fmt(ytd.total_employer_taxes)],
                    ['= True total payroll cost', fmt(ytd.true_total_cost)],
                  ].map(([l, v]) => (
                    <div key={l} className={`preview-row ${l.startsWith('=') ? 'total' : ''}`}>
                      <span>{l}</span><span>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-header"><h3>Key metrics</h3></div>
              <div style={{ padding: 16 }}>
                <div className="preview-box">
                  {[
                    ['Pay runs completed', ytd.run_count],
                    ['Effective employee tax rate', pct(ytd.effective_tax_rate)],
                    ['Avg gross per run', fmt(ytd.total_gross / Math.max(ytd.run_count, 1))],
                    ['Avg net per run', fmt(ytd.total_net / Math.max(ytd.run_count, 1))],
                    ['Employer cost ratio', pct((ytd.total_employer_taxes / Math.max(ytd.total_gross, 1)) * 100)],
                  ].map(([l, v]) => (
                    <div key={l} className="preview-row">
                      <span style={{ color: 'var(--text2)' }}>{l}</span><span style={{ fontWeight: 500 }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ── By Department ───────────────────── */}
      {tab === 'dept' && dept && (
        <div className="card">
          <table className="table">
            <thead>
              <tr>
                <th>Department</th><th>Headcount</th><th>Gross</th>
                <th>Employee Taxes</th><th>Employer Taxes</th><th>Net</th><th>True Cost</th>
              </tr>
            </thead>
            <tbody>
              {dept.departments.length === 0 && (
                <tr><td colSpan={7} className="empty">No data — run payroll first</td></tr>
              )}
              {dept.departments.map(d => (
                <tr key={d.department}>
                  <td style={{ fontWeight: 500 }}>{d.department}</td>
                  <td>{d.headcount}</td>
                  <td>{fmt(d.gross)}</td>
                  <td style={{ color: 'var(--red)' }}>{fmt(d.taxes)}</td>
                  <td style={{ color: 'var(--amber)' }}>{fmt(d.employer_taxes)}</td>
                  <td style={{ color: 'var(--green)', fontWeight: 600 }}>{fmt(d.net)}</td>
                  <td style={{ fontWeight: 600 }}>{fmt(d.true_cost)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Per Employee YTD ────────────────── */}
      {tab === 'emp' && empYtd && (
        <div className="card">
          <div className="card-header">
            <h3>Employee YTD ({empYtd.employees.length} employees)</h3>
            <span style={{ fontSize: 12, color: 'var(--text3)' }}>Use for W-2 preparation</span>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="table" style={{ minWidth: 900 }}>
              <thead>
                <tr>
                  <th>Employee</th><th>Dept</th><th>State</th>
                  <th>YTD Gross</th><th>Fed Tax</th><th>State Tax</th>
                  <th>SS Tax</th><th>Medicare</th><th>401(k)</th><th>YTD Net</th>
                </tr>
              </thead>
              <tbody>
                {empYtd.employees.length === 0 && (
                  <tr><td colSpan={10} className="empty">No data yet</td></tr>
                )}
                {empYtd.employees.map(e => (
                  <tr key={e.id}>
                    <td>
                      <div style={{ fontWeight: 500 }}>{e.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text3)' }}>{e.job_title}</div>
                    </td>
                    <td>{e.department || '—'}</td>
                    <td>{e.state}</td>
                    <td>{fmt(e.ytd_gross)}</td>
                    <td>{fmt(e.ytd_federal_tax)}</td>
                    <td>{fmt(e.ytd_state_tax)}</td>
                    <td>{fmt(e.ytd_social_security)}</td>
                    <td>{fmt(e.ytd_medicare)}</td>
                    <td>{fmt(e.ytd_401k)}</td>
                    <td style={{ fontWeight: 600, color: 'var(--green)' }}>{fmt(e.ytd_net)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Tax Liability ───────────────────── */}
      {tab === 'tax' && tax && (
        <div className="two-col">
          <div className="card">
            <div className="card-header"><h3>IRS Form 941 Liability</h3></div>
            <div style={{ padding: 16 }}>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 12 }}>
                Quarterly 941 deposit — federal income tax + both sides of FICA
              </div>
              <div className="preview-box">
                {[
                  ['Federal income tax withheld', fmt(tax.irs_941_liability.federal_income_tax_withheld)],
                  ['Employee SS (6.2%)', fmt(tax.irs_941_liability.employee_ss)],
                  ['Employer SS (6.2%)', fmt(tax.irs_941_liability.employer_ss)],
                  ['Employee Medicare (1.45%)', fmt(tax.irs_941_liability.employee_medicare)],
                  ['Employer Medicare (1.45%)', fmt(tax.irs_941_liability.employer_medicare)],
                  ['Total 941 deposit due', fmt(tax.irs_941_liability.total_941_deposit)],
                ].map(([l, v]) => (
                  <div key={l} className={`preview-row ${l.includes('Total') ? 'total' : ''}`}>
                    <span>{l}</span><span>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-header"><h3>Other Tax Obligations</h3></div>
            <div style={{ padding: 16 }}>
              <div className="preview-box">
                {[
                  ['IRS Form 940 FUTA', fmt(tax.irs_940_futa)],
                  ['State income tax withheld', fmt(tax.state_income_tax_withheld)],
                  ['SUTA (state unemployment)', fmt(tax.suta)],
                  ['Total all obligations', fmt(tax.total_tax_liability)],
                ].map(([l, v]) => (
                  <div key={l} className={`preview-row ${l.includes('Total') ? 'total' : ''}`}>
                    <span>{l}</span><span>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 12, padding: 10, background: 'var(--amber-bg)', borderRadius: 6, fontSize: 12, color: 'var(--amber)' }}>
                ⚠ These are estimates. Consult a CPA before filing. Tax deposits have strict IRS deadlines.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
