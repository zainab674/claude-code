import React, { useState, useEffect } from 'react';
import * as api from '../services/api';

const STATES = ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA',
'KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC',
'ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'];

export default function CompanySettings() {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getCompany().then(c => setForm(c)).catch(() => {});
  }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async (e) => {
    e.preventDefault();
    setSaving(true); setError(''); setSaved(false);
    try {
      const updated = await api.updateCompany(form);
      setForm(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  };

  if (!form) return <div className="page"><div style={{ padding: 32, color: 'var(--text3)' }}>Loading...</div></div>;

  return (
    <div className="page">
      <div className="page-header"><h1>Company Settings</h1></div>

      {error && <div className="alert alert-danger">{error}</div>}
      {saved && <div className="alert" style={{ background: 'var(--green-bg)', color: 'var(--green)', border: '1px solid #b2dfb2' }}>✓ Settings saved</div>}

      <form onSubmit={save}>
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><h3>Company information</h3></div>
          <div style={{ padding: 16 }}>
            <div className="form-grid">
              <div className="form-group">
                <label>Company name *</label>
                <input type="text" value={form.name || ''} onChange={e => set('name', e.target.value)} required />
              </div>
              <div className="form-group">
                <label>EIN (Employer ID Number)</label>
                <input type="text" value={form.ein || ''} onChange={e => set('ein', e.target.value)} placeholder="12-3456789" />
              </div>
              <div className="form-group">
                <label>Company email</label>
                <input type="email" value={form.email || ''} onChange={e => set('email', e.target.value)} />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input type="text" value={form.phone || ''} onChange={e => set('phone', e.target.value)} />
              </div>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><h3>Address</h3></div>
          <div style={{ padding: 16 }}>
            <div className="form-grid">
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Street address</label>
                <input type="text" value={form.address_line1 || ''} onChange={e => set('address_line1', e.target.value)} />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label>Address line 2</label>
                <input type="text" value={form.address_line2 || ''} onChange={e => set('address_line2', e.target.value)} />
              </div>
              <div className="form-group">
                <label>City</label>
                <input type="text" value={form.city || ''} onChange={e => set('city', e.target.value)} />
              </div>
              <div className="form-group">
                <label>State</label>
                <select value={form.state || 'NY'} onChange={e => set('state', e.target.value)}>
                  {STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>ZIP code</label>
                <input type="text" value={form.zip || ''} onChange={e => set('zip', e.target.value)} />
              </div>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 16 }}>
          <div className="card-header"><h3>Payroll settings</h3></div>
          <div style={{ padding: 16 }}>
            <div className="form-group" style={{ maxWidth: 260 }}>
              <label>Default pay frequency</label>
              <select value={form.pay_frequency || 'biweekly'} onChange={e => set('pay_frequency', e.target.value)}>
                <option value="weekly">Weekly (52×/yr)</option>
                <option value="biweekly">Bi-weekly (26×/yr)</option>
                <option value="semimonthly">Semi-monthly (24×/yr)</option>
                <option value="monthly">Monthly (12×/yr)</option>
              </select>
            </div>
          </div>
        </div>

        <button className="btn btn-primary" type="submit" disabled={saving}>
          {saving ? 'Saving...' : '✓ Save settings'}
        </button>
      </form>
    </div>
  );
}
