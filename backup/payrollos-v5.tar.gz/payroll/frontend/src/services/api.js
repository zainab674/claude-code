const BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function getToken() { return localStorage.getItem('payroll_token'); }

async function request(path, options = {}) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (res.status === 401) {
    localStorage.removeItem('payroll_token');
    localStorage.removeItem('payroll_user');
    window.location.href = '/';
    return;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || 'Request failed');
  }
  if (res.status === 204) return null;
  return res.json();
}

export const login = (email, password) =>
  request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
export const register = (data) =>
  request('/auth/register', { method: 'POST', body: JSON.stringify(data) });

export const getCompany = () => request('/company');
export const updateCompany = (data) =>
  request('/company', { method: 'PUT', body: JSON.stringify(data) });

const clean = (p) => Object.fromEntries(Object.entries(p).filter(([,v]) => v !== undefined && v !== '' && v !== null));
export const getEmployees = (p = {}) => request(`/employees?${new URLSearchParams(clean(p))}`);
export const getEmployee = (id) => request(`/employees/${id}`);
export const createEmployee = (data) => request('/employees', { method: 'POST', body: JSON.stringify(data) });
export const updateEmployee = (id, data) => request(`/employees/${id}`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteEmployee = (id) => request(`/employees/${id}`, { method: 'DELETE' });

export const getTimeEntries = (p = {}) => request(`/time?${new URLSearchParams(clean(p))}`);
export const createTimeEntry = (data) => request('/time', { method: 'POST', body: JSON.stringify(data) });
export const updateTimeEntry = (id, data) => request(`/time/${id}`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteTimeEntry = (id) => request(`/time/${id}`, { method: 'DELETE' });
export const getTimeSummary = (employee_id, start_date, end_date) =>
  request(`/time/summary?employee_id=${employee_id}&start_date=${start_date}&end_date=${end_date}`);

export const getPayPeriods = (p = {}) => request(`/pay-periods?${new URLSearchParams(clean(p))}`);
export const createPayPeriod = (data) => request('/pay-periods', { method: 'POST', body: JSON.stringify(data) });
export const generatePayPeriods = (frequency, count, start_date) =>
  request(`/pay-periods/generate?frequency=${frequency}&count=${count}${start_date ? '&start_date=' + start_date : ''}`, { method: 'POST' });

export const previewPayroll = (data) => request('/payroll/preview', { method: 'POST', body: JSON.stringify(data) });
export const runPayroll = (data) => request('/payroll/run', { method: 'POST', body: JSON.stringify(data) });
export const getPayrollHistory = (p = {}) => request(`/payroll/history?${new URLSearchParams(clean(p))}`);
export const getPayRun = (id) => request(`/payroll/history/${id}`);
export const calculatePaycheck = (data) => request('/payroll/calculate', { method: 'POST', body: JSON.stringify(data) });

export const getPaystubs = (p = {}) => request(`/paystubs?${new URLSearchParams(clean(p))}`);
export const getPaystub = (id) => request(`/paystubs/${id}`);
export const downloadPaystub = (id) => `${BASE}/paystubs/${id}/download`;

export const getYtdSummary = (year) => request(`/reports/ytd-summary${year ? '?year=' + year : ''}`);
export const getByDepartment = (year) => request(`/reports/by-department${year ? '?year=' + year : ''}`);
export const getEmployeeYtd = (year) => request(`/reports/employee-ytd${year ? '?year=' + year : ''}`);
export const getTaxLiability = (year) => request(`/reports/tax-liability${year ? '?year=' + year : ''}`);
