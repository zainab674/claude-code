from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql://payroll:payroll_secret@localhost:5432/payrolldb"
    JWT_SECRET: str = "change_this_in_production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 480
    CORS_ORIGINS: str = "http://localhost:3000"
    PAYSTUB_DIR: str = "./paystubs"

    class Config:
        env_file = ".env"

settings = Settings()
