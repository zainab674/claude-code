from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import get_db
from models import Paystub, PayRunItem, Employee, Company, PayPeriod, PayRun
from services.pdf_generator import generate_paystub_pdf
from utils.auth import get_current_user
from datetime import datetime

router = APIRouter(prefix="/paystubs", tags=["paystubs"])


@router.get("")
async def list_paystubs(
    employee_id: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    q = select(Paystub).where(Paystub.company_id == current_user["company_id"])
    if employee_id:
        q = q.where(Paystub.employee_id == employee_id)
    q = q.order_by(Paystub.created_at.desc()).limit(100)
    result = await db.execute(q)
    stubs = result.scalars().all()
    return [{"id": str(s.id), "employee_id": str(s.employee_id),
             "pay_run_id": str(s.pay_run_id), "created_at": str(s.created_at)} for s in stubs]


@router.get("/{paystub_id}")
async def get_paystub(
    paystub_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    result = await db.execute(
        select(Paystub).where(Paystub.id == paystub_id, Paystub.company_id == current_user["company_id"])
    )
    stub = result.scalar_one_or_none()
    if not stub:
        raise HTTPException(404, "Paystub not found")

    # Load related data
    item_res = await db.execute(select(PayRunItem).where(PayRunItem.id == stub.pay_run_item_id))
    item = item_res.scalar_one()

    emp_res = await db.execute(select(Employee).where(Employee.id == stub.employee_id))
    emp = emp_res.scalar_one()

    co_res = await db.execute(select(Company).where(Company.id == stub.company_id))
    company = co_res.scalar_one()

    run_res = await db.execute(select(PayRun).where(PayRun.id == stub.pay_run_id))
    run = run_res.scalar_one()

    period_res = await db.execute(select(PayPeriod).where(PayPeriod.id == run.pay_period_id))
    period = period_res.scalar_one()

    return {
        "paystub_id": str(stub.id),
        "employee": {
            "id": str(emp.id),
            "first_name": emp.first_name,
            "last_name": emp.last_name,
            "job_title": emp.job_title,
            "department": emp.department,
        },
        "company": {
            "name": company.name,
            "ein": company.ein,
            "address_line1": company.address_line1,
            "city": company.city,
            "state": company.state,
            "zip": company.zip,
        },
        "pay_period": {
            "period_start": str(period.period_start),
            "period_end": str(period.period_end),
            "pay_date": str(period.pay_date),
        },
        "earnings": {
            "regular_pay": float(item.regular_pay or 0),
            "overtime_pay": float(item.overtime_pay or 0),
            "bonus_pay": float(item.bonus_pay or 0),
            "gross_pay": float(item.gross_pay or 0),
        },
        "deductions": {
            "health_insurance": float(item.health_insurance or 0),
            "dental_insurance": float(item.dental_insurance or 0),
            "vision_insurance": float(item.vision_insurance or 0),
            "retirement_401k": float(item.retirement_401k or 0),
            "hsa": float(item.hsa or 0),
            "total_pretax": float(item.total_pretax_deductions or 0),
        },
        "taxes": {
            "federal_income_tax": float(item.federal_income_tax or 0),
            "state_income_tax": float(item.state_income_tax or 0),
            "social_security_tax": float(item.social_security_tax or 0),
            "medicare_tax": float(item.medicare_tax or 0),
            "total_employee_taxes": float(item.total_employee_taxes or 0),
        },
        "employer_taxes": {
            "employer_social_security": float(item.employer_social_security or 0),
            "employer_medicare": float(item.employer_medicare or 0),
            "futa_tax": float(item.futa_tax or 0),
            "total_employer_taxes": float(item.total_employer_taxes or 0),
        },
        "net_pay": float(item.net_pay or 0),
        "ytd": {
            "gross": float(item.ytd_gross or 0),
            "federal_tax": float(item.ytd_federal_tax or 0),
            "social_security": float(item.ytd_social_security or 0),
            "medicare": float(item.ytd_medicare or 0),
            "net": float(item.ytd_net or 0),
        },
    }


@router.get("/{paystub_id}/download")
async def download_paystub_pdf(
    paystub_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
):
    """Generate and stream the paystub PDF."""
    data = await get_paystub(paystub_id, db, current_user)

    pdf_path = generate_paystub_pdf(
        employee=data["employee"],
        company=data["company"],
        pay_period=data["pay_period"],
        pay_item={**data["earnings"], **data["deductions"], **data["taxes"],
                  **data["employer_taxes"], **data["ytd"],
                  "net_pay": data["net_pay"],
                  "total_employer_taxes": data["employer_taxes"]["total_employer_taxes"]},
    )

    # Update viewed_at
    result = await db.execute(select(Paystub).where(Paystub.id == paystub_id))
    stub = result.scalar_one()
    stub.viewed_at = datetime.utcnow()
    await db.commit()

    name = f"paystub_{data['employee']['last_name']}_{data['pay_period']['period_end']}.pdf"
    return FileResponse(pdf_path, media_type="application/pdf", filename=name)
