import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Boolean, Numeric, Integer, Date, DateTime,
    ForeignKey, Text, CheckConstraint
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database import Base


class Company(Base):
    __tablename__ = "companies"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    ein = Column(String(20))
    address_line1 = Column(String(255))
    address_line2 = Column(String(255))
    city = Column(String(100))
    state = Column(String(2))
    zip = Column(String(10))
    phone = Column(String(20))
    email = Column(String(255))
    pay_frequency = Column(String(20), default="biweekly")
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    employees = relationship("Employee", back_populates="company")
    pay_periods = relationship("PayPeriod", back_populates="company")
    pay_runs = relationship("PayRun", back_populates="company")


class User(Base):
    __tablename__ = "users"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"))
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(Text, nullable=False)
    role = Column(String(20), default="admin")
    first_name = Column(String(100))
    last_name = Column(String(100))
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)


class Employee(Base):
    __tablename__ = "employees"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)
    employee_number = Column(String(50), unique=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255))
    phone = Column(String(20))
    hire_date = Column(Date, nullable=False)
    termination_date = Column(Date)
    status = Column(String(20), default="active")
    pay_type = Column(String(20), nullable=False)
    pay_rate = Column(Numeric(12, 4), nullable=False)
    pay_frequency = Column(String(20), default="biweekly")
    department = Column(String(100))
    job_title = Column(String(150))
    filing_status = Column(String(20), default="single")
    federal_allowances = Column(Integer, default=0)
    additional_federal_withholding = Column(Numeric(10, 2), default=0)
    state_code = Column(String(2), default="NY")
    exempt_from_federal = Column(Boolean, default=False)
    exempt_from_state = Column(Boolean, default=False)
    health_insurance_deduction = Column(Numeric(10, 2), default=0)
    dental_deduction = Column(Numeric(10, 2), default=0)
    vision_deduction = Column(Numeric(10, 2), default=0)
    retirement_401k_pct = Column(Numeric(5, 4), default=0)
    hsa_deduction = Column(Numeric(10, 2), default=0)
    garnishment_amount = Column(Numeric(10, 2), default=0)
    garnishment_type = Column(String(50))
    address_line1 = Column(String(255))
    city = Column(String(100))
    state = Column(String(2))
    zip = Column(String(10))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    company = relationship("Company", back_populates="employees")
    pay_run_items = relationship("PayRunItem", back_populates="employee")
    paystubs = relationship("Paystub", back_populates="employee")


class PayPeriod(Base):
    __tablename__ = "pay_periods"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    pay_date = Column(Date, nullable=False)
    status = Column(String(20), default="open")
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    company = relationship("Company", back_populates="pay_periods")
    pay_runs = relationship("PayRun", back_populates="pay_period")


class PayRun(Base):
    __tablename__ = "pay_runs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)
    pay_period_id = Column(UUID(as_uuid=True), ForeignKey("pay_periods.id"), nullable=False)
    status = Column(String(20), default="draft")
    total_gross = Column(Numeric(14, 2), default=0)
    total_employee_taxes = Column(Numeric(14, 2), default=0)
    total_employer_taxes = Column(Numeric(14, 2), default=0)
    total_deductions = Column(Numeric(14, 2), default=0)
    total_net = Column(Numeric(14, 2), default=0)
    employee_count = Column(Integer, default=0)
    notes = Column(Text)
    approved_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_at = Column(DateTime(timezone=True))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    completed_at = Column(DateTime(timezone=True))

    company = relationship("Company", back_populates="pay_runs")
    pay_period = relationship("PayPeriod", back_populates="pay_runs")
    items = relationship("PayRunItem", back_populates="pay_run", cascade="all, delete-orphan")


class PayRunItem(Base):
    __tablename__ = "pay_run_items"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pay_run_id = Column(UUID(as_uuid=True), ForeignKey("pay_runs.id", ondelete="CASCADE"), nullable=False)
    employee_id = Column(UUID(as_uuid=True), ForeignKey("employees.id"), nullable=False)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    regular_hours = Column(Numeric(8, 2), default=0)
    overtime_hours = Column(Numeric(8, 2), default=0)
    double_time_hours = Column(Numeric(8, 2), default=0)
    pto_hours = Column(Numeric(8, 2), default=0)
    sick_hours = Column(Numeric(8, 2), default=0)
    regular_pay = Column(Numeric(12, 2), default=0)
    overtime_pay = Column(Numeric(12, 2), default=0)
    bonus_pay = Column(Numeric(12, 2), default=0)
    commission_pay = Column(Numeric(12, 2), default=0)
    reimbursement = Column(Numeric(12, 2), default=0)
    gross_pay = Column(Numeric(12, 2), default=0)
    federal_income_tax = Column(Numeric(10, 2), default=0)
    state_income_tax = Column(Numeric(10, 2), default=0)
    local_income_tax = Column(Numeric(10, 2), default=0)
    social_security_tax = Column(Numeric(10, 2), default=0)
    medicare_tax = Column(Numeric(10, 2), default=0)
    additional_medicare_tax = Column(Numeric(10, 2), default=0)
    sdi_tax = Column(Numeric(10, 2), default=0)
    total_employee_taxes = Column(Numeric(10, 2), default=0)
    employer_social_security = Column(Numeric(10, 2), default=0)
    employer_medicare = Column(Numeric(10, 2), default=0)
    futa_tax = Column(Numeric(10, 2), default=0)
    suta_tax = Column(Numeric(10, 2), default=0)
    total_employer_taxes = Column(Numeric(10, 2), default=0)
    health_insurance = Column(Numeric(10, 2), default=0)
    dental_insurance = Column(Numeric(10, 2), default=0)
    vision_insurance = Column(Numeric(10, 2), default=0)
    retirement_401k = Column(Numeric(10, 2), default=0)
    hsa = Column(Numeric(10, 2), default=0)
    total_pretax_deductions = Column(Numeric(10, 2), default=0)
    garnishment = Column(Numeric(10, 2), default=0)
    total_posttax_deductions = Column(Numeric(10, 2), default=0)
    net_pay = Column(Numeric(12, 2), default=0)
    ytd_gross = Column(Numeric(14, 2), default=0)
    ytd_federal_tax = Column(Numeric(14, 2), default=0)
    ytd_social_security = Column(Numeric(14, 2), default=0)
    ytd_medicare = Column(Numeric(14, 2), default=0)
    ytd_net = Column(Numeric(14, 2), default=0)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    pay_run = relationship("PayRun", back_populates="items")
    employee = relationship("Employee", back_populates="pay_run_items")
    paystub = relationship("Paystub", back_populates="pay_run_item", uselist=False)


class Paystub(Base):
    __tablename__ = "paystubs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pay_run_item_id = Column(UUID(as_uuid=True), ForeignKey("pay_run_items.id", ondelete="CASCADE"), nullable=False)
    employee_id = Column(UUID(as_uuid=True), ForeignKey("employees.id"), nullable=False)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id"), nullable=False)
    pay_run_id = Column(UUID(as_uuid=True), ForeignKey("pay_runs.id"), nullable=False)
    pdf_path = Column(Text)
    pdf_generated_at = Column(DateTime(timezone=True))
    viewed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)

    pay_run_item = relationship("PayRunItem", back_populates="paystub")
    employee = relationship("Employee", back_populates="paystubs")
