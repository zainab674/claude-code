"""
Audit log — immutable record of all payroll actions.
Every payroll run, employee change, and login is recorded here.
"""
from datetime import datetime
import uuid
from sqlalchemy import Column, String, Text, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from database import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"))
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    user_email = Column(String(255))
    action = Column(String(100), nullable=False)   # e.g. "employee.created", "payroll.run"
    resource_type = Column(String(50))              # e.g. "employee", "pay_run"
    resource_id = Column(String(100))               # UUID of affected resource
    details = Column(JSONB, default=dict)            # arbitrary JSON detail
    ip_address = Column(String(45))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
