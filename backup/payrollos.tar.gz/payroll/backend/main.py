from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from config import settings
from routes import auth, employees, payroll, paystubs
import os

app = FastAPI(
    title="PayrollOS API",
    description="Complete payroll system API - built in 3 days",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(auth.router)
app.include_router(employees.router)
app.include_router(payroll.router)
app.include_router(paystubs.router)

os.makedirs(settings.PAYSTUB_DIR, exist_ok=True)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "PayrollOS API"}


@app.get("/")
async def root():
    return {
        "service": "PayrollOS API",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "auth": "/auth/login | /auth/register",
            "employees": "/employees",
            "payroll_preview": "/payroll/preview",
            "payroll_run": "/payroll/run",
            "payroll_history": "/payroll/history",
            "payroll_calculator": "/payroll/calculate",
            "paystubs": "/paystubs/{id}",
            "paystub_pdf": "/paystubs/{id}/download",
        }
    }
