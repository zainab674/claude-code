const BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function getToken() {
  return localStorage.getItem('payroll_token');
}

async function request(path, options = {}) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (res.status === 401) {
    localStorage.removeItem('payroll_token');
    window.location.href = '/login';
    return;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || 'Request failed');
  }
  if (res.status === 204) return null;
  return res.json();
}

// Auth
export const login = (email, password) =>
  request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });

export const register = (data) =>
  request('/auth/register', { method: 'POST', body: JSON.stringify(data) });

// Employees
export const getEmployees = (params = {}) => {
  const qs = new URLSearchParams(params).toString();
  return request(`/employees${qs ? '?' + qs : ''}`);
};
export const getEmployee = (id) => request(`/employees/${id}`);
export const createEmployee = (data) =>
  request('/employees', { method: 'POST', body: JSON.stringify(data) });
export const updateEmployee = (id, data) =>
  request(`/employees/${id}`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteEmployee = (id) =>
  request(`/employees/${id}`, { method: 'DELETE' });

// Payroll
export const previewPayroll = (data) =>
  request('/payroll/preview', { method: 'POST', body: JSON.stringify(data) });
export const runPayroll = (data) =>
  request('/payroll/run', { method: 'POST', body: JSON.stringify(data) });
export const getPayrollHistory = (params = {}) => {
  const qs = new URLSearchParams(params).toString();
  return request(`/payroll/history${qs ? '?' + qs : ''}`);
};
export const getPayRun = (id) => request(`/payroll/history/${id}`);
export const calculatePaycheck = (data) =>
  request('/payroll/calculate', { method: 'POST', body: JSON.stringify(data) });

// Paystubs
export const getPaystubs = (params = {}) => {
  const qs = new URLSearchParams(params).toString();
  return request(`/paystubs${qs ? '?' + qs : ''}`);
};
export const getPaystub = (id) => request(`/paystubs/${id}`);
export const downloadPaystub = (id) => `${BASE}/paystubs/${id}/download`;
